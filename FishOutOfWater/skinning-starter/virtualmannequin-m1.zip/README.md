# VirtualMannequin
Group members:
Aparna Majety (apm3222)
Sumedha Gonur (sg55696)

Taking 1 slip day for Milestone 1

Design decisions: For our bone picking, we decided to do the highlighting by changing the bone color instead of putting a visible cylinder. 

Contribution report: We pair programmed the entire project. 50-50.

Extra Credit:
We have implemented a way to translate root joints using the keyboard.
When a root bone is highlighted on hover, not on click: 
Key F moves the root bone to the camera left direction.
Key H moves the root bone to the camera right direction.
Key T moves the root bone to the camera forward direction.
Key G moves the root bone to the camera backward direction.
Key O moves the root bone to the camera up direction.
Key P moves the root bone to the camera down direction.