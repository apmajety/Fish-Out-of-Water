import { Camera } from "../lib/webglutils/Camera.js";
import { CanvasAnimation } from "../lib/webglutils/CanvasAnimation.js";
import { SkinningAnimation } from "./App.js";
import { Mat4, Mat3, Vec3, Vec4, Vec2, Mat2, Quat } from "../lib/TSM.js";
import { Bone } from "./Scene.js";
import { RenderPass } from "../lib/webglutils/RenderPass.js";

/**
 * Might be useful for designing any animation GUI
 */
interface IGUI {
  viewMatrix(): Mat4;
  projMatrix(): Mat4;
  dragStart(me: MouseEvent): void;
  drag(me: MouseEvent): void;
  dragEnd(me: MouseEvent): void;
  onKeydown(ke: KeyboardEvent): void;
}

export enum Mode {
  playback,  
  edit  
}

	
/**
 * Handles Mouse and Button events along with
 * the the camera.
 */

export class GUI implements IGUI {
  private static readonly rotationSpeed: number = 0.05;
  private static readonly zoomSpeed: number = 0.1;
  private static readonly rollSpeed: number = 0.1;
  private static readonly panSpeed: number = 0.1;

  private camera: Camera;
  private dragging: boolean;
  private fps: boolean;
  private prevX: number;
  private prevY: number;
  private prevX2: number;
  private prevY2: number;

  private height: number;
  private viewPortHeight: number;
  private width: number;

  private animation: SkinningAnimation;

  public selectedBone: number;
  private boneDragging: boolean = false;
  private boneSelected: boolean = false;
  
  public closestBone: Bone;

  public time: number;
  public mode: Mode;

  public hoverX: number = 0;
  public hoverY: number = 0;


  /**
   *
   * @param canvas required to get the width and height of the canvas
   * @param animation required as a back pointer for some of the controls
   * @param sponge required for some of the controls
   */
  constructor(canvas: HTMLCanvasElement, animation: SkinningAnimation) {
    this.height = canvas.height;
    this.viewPortHeight = this.height - 200;
    this.width = canvas.width;
    this.prevX = 0;
    this.prevY = 0;
    
    this.animation = animation;
    
    this.reset();
    
    this.registerEventListeners(canvas);
  }

  public getNumKeyFrames(): number {
    //TODO: Fix for the status bar in the GUI
    return 0;
  }
  
  public getTime(): number { 
  	return this.time; 
  }
  
  public getMaxTime(): number { 
    //TODO: The animation should stop after the last keyframe
    return 0;
  }

  /**
   * Resets the state of the GUI
   */
  public reset(): void {
    this.fps = false;
    this.dragging = false;
    this.time = 0;
	this.mode = Mode.edit;
    
    this.camera = new Camera(
      new Vec3([0, 0, -6]),
      new Vec3([0, 0, 0]),
      new Vec3([0, 1, 0]),
      45,
      this.width / this.viewPortHeight,
      0.1,
      1000.0
    );
  }

  /**
   * Sets the GUI's camera to the given camera
   * @param cam a new camera
   */
  public setCamera(
    pos: Vec3,
    target: Vec3,
    upDir: Vec3,
    fov: number,
    aspect: number,
    zNear: number,
    zFar: number
  ) {
    this.camera = new Camera(pos, target, upDir, fov, aspect, zNear, zFar);
  }

  /**
   * Returns the view matrix of the camera
   */
  public viewMatrix(): Mat4 {
    return this.camera.viewMatrix();
  }

  /**
   * Returns the projection matrix of the camera
   */
  public projMatrix(): Mat4 {
    return this.camera.projMatrix();
  }

  /**
   * Callback function for the start of a drag event.
   * @param mouse
   */
  public dragStart(mouse: MouseEvent): void {
    if (mouse.offsetY > 600) {
      // outside the main panel
      return; 
    }
	
    // TODO: Add logic to rotate the bones, instead of moving the camera, if there is a currently highlighted bone
    
    this.dragging = true;
    this.prevX = mouse.screenX;
    this.prevY = mouse.screenY;
    this.prevX2 = mouse.offsetX;
    this.prevY2 = mouse.offsetY;

    if (this.boneSelected) {
      this.boneDragging = true;
    }
    console.log("drag start function- dragging: " + this.dragging + " bone dragging: " + this.boneDragging + " bone selected: "+ this.boneSelected);
  }

  public incrementTime(dT: number): void {
    if (this.mode === Mode.playback) {
      this.time += dT;
      if (this.time >= this.getMaxTime()) {
        this.time = 0;
        this.mode = Mode.edit;
      }
    }
  }
  

  /**
   * The callback function for a drag event.
   * This event happens after dragStart and
   * before dragEnd.
   * @param mouse
   */
  public drag(mouse: MouseEvent): void {
    let x = mouse.offsetX;
    let y = mouse.offsetY;
    console.log("start of drag function booleans- dragging: " + this.dragging + " bone dragging: " + this.boneDragging + " bone selected: "+ this.boneSelected);


    
    const ndcX = (x / this.width) * 2 - 1;
    const ndcY = 1 - (y / this.viewPortHeight) * 2;
    
    console.log("ndc x: " + ndcX + " ndc y: " + ndcY);
 
    const nearPoint = new Vec4([ndcX, ndcY, -1, 1]); // Near plane
    const farPoint = new Vec4([ndcX, ndcY, 1, 1]);   // Far plane
 
    const invProjMatrix = this.camera.projMatrix().inverse();
    const invViewMatrix = this.camera.viewMatrix().inverse();
    const invProjViewMatrix = invProjMatrix.multiply(invViewMatrix);


    const nearWorldPoint = nearPoint.multiplyMat4(this.camera.projMatrix().inverse()).multiplyMat4(this.camera.viewMatrix().inverse());
    const farWorldPoint = farPoint.multiplyMat4(this.camera.projMatrix().inverse()).multiplyMat4(this.camera.viewMatrix().inverse());
  
    nearWorldPoint.scale(1.0 / nearWorldPoint.w);
    farWorldPoint.scale(1.0 / farWorldPoint.w);
    
  
    const rayOrigin = new Vec4([nearWorldPoint.x, nearWorldPoint.y, nearWorldPoint.z, 1.0]);
    const rayDirection = new Vec4([
      farWorldPoint.x - nearWorldPoint.x,
      farWorldPoint.y - nearWorldPoint.y,
      farWorldPoint.z - nearWorldPoint.z,
      0.0
  ]).normalize();

    console.log("ray origin world coords: " + rayOrigin.xyz.toString());
    console.log("ray direction world coords: " + rayDirection.xyz.toString());
  
    // Find closest bone intersection
    let closestDistance = Number.MAX_VALUE;
    let closestBoneIndex = -1;

    if (!this.dragging && !this.boneDragging) {
      console.log("hover case, dragging: " + this.dragging + " bone dragging: " + this.boneDragging + " bone selected: "+ this.boneSelected);
      this.animation.getScene().meshes[0].bones.forEach((bone, index) => {

      
          let bone_local_y = new Vec3(bone.endpoint.copy().subtract(bone.position).xyz).normalize();
          let rand_vec;
          
          
          if(Math.abs(bone_local_y.x) <= Math.abs(bone_local_y.y) && Math.abs(bone_local_y.x) <= Math.abs(bone_local_y.z)) {
            rand_vec = new Vec3([1, 0, 0]);
          } else if(Math.abs(bone_local_y.y) <= Math.abs(bone_local_y.x) && Math.abs(bone_local_y.y) <= Math.abs(bone_local_y.z)) {
              rand_vec = new Vec3([0, 1, 0]);
          } else {
              rand_vec = new Vec3([0, 0, 1]);
          }

          
       
          
          let bone_local_x = Vec3.cross(bone_local_y.copy(), rand_vec.copy()).normalize();
          let bone_local_z = Vec3.cross(bone_local_x.copy(), bone_local_y.copy()).normalize();
          
          
          
          const translation = new Mat4([
              1.0, 0.0, 0.0, 0.0,
              0.0, 1.0, 0.0, 0.0,
              0.0, 0.0, 1.0, 0.0,
              -bone.position.x, -bone.position.y, -bone.position.z, 1.0
          ]);
          
          
          const rotation = new Mat4([
              bone_local_x.x, bone_local_y.x, bone_local_z.x, 0.0,
              bone_local_x.y, bone_local_y.y, bone_local_z.y, 0.0,
              bone_local_x.z, bone_local_y.z, bone_local_z.z, 0.0,
              0.0, 0.0, 0.0, 1.0
          ]);
          
          
          const bone_local = rotation.multiply(translation);
          const rayOriginBone = bone_local.multiplyVec4(rayOrigin);
const rayDirBone = bone_local.multiplyVec4(rayDirection).normalize();

// Get bone length
const boneLength = bone.endpoint.copy().subtract(bone.position).length();
const radius = 0.05; // Cylinder radius

// Variable to track if we have an intersection
let foundIntersection = false;
let tIntersect = Number.MAX_VALUE;

// First check cap intersections
if (rayDirBone.y !== 0) {
  // Check intersection with cap at y = 0 (bottom cap)
  const t1 = -rayOriginBone.y / rayDirBone.y;
  
  // Check intersection with cap at y = boneLength (top cap)
  const t2 = (boneLength - rayOriginBone.y) / rayDirBone.y;
  
  // Check which cap intersections are valid
  [t1, t2].forEach(t => {
    if (t >= 0) {
      // Calculate intersection point
      const px = rayOriginBone.x + rayDirBone.x * t;
      const pz = rayOriginBone.z + rayDirBone.z * t;
      
      // Check if point is within cap radius
      if (px * px + pz * pz <= radius) {
        if (t < tIntersect) {
          tIntersect = t;
          foundIntersection = true;
        }
      }
    }
  });
}

// Then check cylinder body intersection
const a = rayDirBone.x * rayDirBone.x + rayDirBone.z * rayDirBone.z;
const b = 2 * (rayOriginBone.x * rayDirBone.x + rayOriginBone.z * rayDirBone.z);
const c = rayOriginBone.x * rayOriginBone.x + rayOriginBone.z * rayOriginBone.z - radius;

if (a !== 0) {
  const discriminant = b * b - 4 * a * c;
  if (discriminant >= 0.0) {
    const t1 = (-b + Math.sqrt(discriminant)) / (2 * a);
    const t2 = (-b - Math.sqrt(discriminant)) / (2 * a);
    
    // Check positive t values
    const tCandidates = [t1, t2].filter(val => val >= 0.0);
    
    tCandidates.forEach(t => {
      const intersectPoint = new Vec4([
        rayOriginBone.x + rayDirBone.x * t,
        rayOriginBone.y + rayDirBone.y * t,
        rayOriginBone.z + rayDirBone.z * t,
        1.0
      ]);
      
      // Check if intersection is within bone height
      if (intersectPoint.y >= 0 && intersectPoint.y <= boneLength) {
        if (t < tIntersect) {
          tIntersect = t;
          foundIntersection = true;
        }
      }
    });
  }
}

// If we found any intersection with this bone, check if it's the closest
if (foundIntersection && tIntersect < closestDistance) {
  closestDistance = tIntersect;
  closestBoneIndex = index;
  this.closestBone = bone;
  this.boneSelected = true;
}
});

if (closestBoneIndex === -1) {
  this.boneSelected = false;
  this.closestBone = null!;
}
      //console.log("en- dragging: " + this.dragging + " bone dragging: " + this.boneDragging + " bone selected: "+ this.boneSelected);
      this.selectedBone = closestBoneIndex;
      console.log("bone position: " + this.closestBone.position.xyz.toString() + " bone endpoint: " + this.closestBone.endpoint.xyz.toString());
     
        
    }
  
    if (this.dragging && this.boneDragging) {

      //console.log("dragging and bone dragging- dragging: " + this.dragging + " bone dragging: " + this.boneDragging + " bone selected: "+ this.boneSelected);
      //console.log(" screen x: " + x + "  screen y: " + y);
      const ProjViewMatrix = this.camera.viewMatrix().copy().multiply(this.camera.projMatrix());

      const boneEndNDC = (new Vec4([this.closestBone.endpoint.x, this.closestBone.endpoint.y, this.closestBone.endpoint.z, 1.0])).multiplyMat4(this.camera.viewMatrix().copy()).multiplyMat4(this.camera.projMatrix().copy());
      //console.log("bone end NDC:" + boneEndNDC.xyzw.toString());
      boneEndNDC.scale(1.0 / boneEndNDC.w);
      
      const boneEndScreen = ((boneEndNDC.x + 1)/2) * this.width;
      const boneEndScreenY = ((1 - boneEndNDC.y)/2) * this.viewPortHeight;
      //console.log("bone end screen x: " + boneEndScreen + " bone end screen y: " + boneEndScreenY);
      const boneEndScreenCoords = new Vec2([boneEndScreen, boneEndScreenY]);
    
      const boneNDC = (new Vec4([this.closestBone.position.x, this.closestBone.position.y, this.closestBone.position.z, 1.0])).multiplyMat4(this.camera.viewMatrix().copy()).multiplyMat4(this.camera.projMatrix().copy());
      //console.log("bone NDC:" + boneNDC.xyzw.toString());
      boneNDC.scale(1.0 / boneNDC.w);

      const boneScreen = ((boneNDC.x + 1)/2) * this.width;
      const boneScreenY = ((1 - boneNDC.y)/2) * this.viewPortHeight;
      //console.log("bone screen x: " + boneScreen + " bone screen y: " + boneScreenY);
      const boneScreenCoords = new Vec2([boneScreen, boneScreenY]);

      let startVector = boneEndScreenCoords.subtract(boneScreenCoords).normalize();
      let endVector = new Vec2([x, y]).subtract(boneScreenCoords).normalize();
      let rotationAngle = (Math.atan2(startVector.y, startVector.x) - Math.atan2(endVector.y, endVector.x));

      //const rotation = this.closestBone.rotate(this.camera.forward(), rotationAngle);
      const rotation = this.closestBone.rotate((this.closestBone.dMat.toMat3().inverse()).multiplyVec3(this.camera.forward().normalize()), rotationAngle);
      this.closestBone.printMat4(rotation);
      this.closestBone.boneRotation(rotation);
    }else if (this.dragging) {
      console.log("drag- dragging: " + this.dragging + " bone dragging: " + this.boneDragging + " bone selected: "+ this.boneSelected);
      console.log("just dragging no bone select");
      const dx = mouse.screenX - this.prevX;
      const dy = mouse.screenY - this.prevY;
      this.prevX = mouse.screenX;
      this.prevY = mouse.screenY;

      /* Left button, or primary button */
      const mouseDir: Vec3 = this.camera.right();
      mouseDir.scale(-dx);
      mouseDir.add(this.camera.up().scale(dy));
      mouseDir.normalize();

      if (dx === 0 && dy === 0) {
        return;
      }

      switch (mouse.buttons) {
        case 1: {
          let rotAxis: Vec3 = Vec3.cross(this.camera.forward(), mouseDir);
          rotAxis = rotAxis.normalize();

          if (this.fps) {
            this.camera.rotate(rotAxis, GUI.rotationSpeed);
          } else {
            this.camera.orbitTarget(rotAxis, GUI.rotationSpeed);
          }
          break;
        }
        case 2: {
          /* Right button, or secondary button */
          this.camera.offsetDist(Math.sign(mouseDir.y) * GUI.zoomSpeed);
          break;
        }
        default: {
          break;
        }
      }
    }

    
    
    // TODO: Add logic here:
    // 1) To highlight a bone, if the mouse is hovering over a bone;
    // 2) To rotate a bone, if the mouse button is pressed and currently highlighting a bone.
  }
  
 
  public getModeString(): string {
    switch (this.mode) {
      case Mode.edit: { return "edit: " + this.getNumKeyFrames() + " keyframes"; }
      case Mode.playback: { return "playback: " + this.getTime().toFixed(2) + " / " + this.getMaxTime().toFixed(2); }
    }
  }
  
  /**
   * Callback function for the end of a drag event
   * @param mouse
   */
  public dragEnd(mouse: MouseEvent): void {
    this.dragging = false;
    this.prevX = 0;
    this.prevY = 0;
    this.boneDragging = false;
    console.log("drag end function booleans- dragging: " + this.dragging + " bone dragging: " + this.boneDragging + " bone selected: "+ this.boneSelected);
	
    // TODO: Handle ending highlight/dragging logic as needed
    
  }

  /**
   * Callback function for a key press event
   * @param key
   */
  public onKeydown(key: KeyboardEvent): void {
    switch (key.code) {
      case "Digit1": {
        this.animation.setScene("./static/assets/skinning/split_cube.dae");
        break;
      }
      case "Digit2": {
        this.animation.setScene("./static/assets/skinning/long_cubes.dae");
        break;
      }
      case "Digit3": {
        this.animation.setScene("./static/assets/skinning/simple_art.dae");
        break;
      }      
      case "Digit4": {
        this.animation.setScene("./static/assets/skinning/mapped_cube.dae");
        break;
      }
      case "Digit5": {
        this.animation.setScene("./static/assets/skinning/robot.dae");
        break;
      }
      case "Digit6": {
        this.animation.setScene("./static/assets/skinning/head.dae");
        break;
      }
      case "Digit7": {
        this.animation.setScene("./static/assets/skinning/wolf.dae");
        break;
      }
      case "KeyW": {
        this.camera.offset(
            this.camera.forward().negate(),
            GUI.zoomSpeed,
            true
          );
        break;
      }
      case "KeyA": {
        this.camera.offset(this.camera.right().negate(), GUI.zoomSpeed, true);
        break;
      }
      case "KeyS": {
        this.camera.offset(this.camera.forward(), GUI.zoomSpeed, true);
        break;
      }
      case "KeyD": {
        this.camera.offset(this.camera.right(), GUI.zoomSpeed, true);
        break;
      }
      case "KeyR": {
        this.animation.reset();
        break;
      }
      case "ArrowLeft": {
		//TODO: Handle bone rolls when a bone is selected
    if (this.boneSelected) {
      //this.closestBone.boneRotation(this.closestBone.rotate(new Vec3(this.closestBone.ogEndpoint.xyz).normalize(), -GUI.rollSpeed));
      this.closestBone.boneRotation(this.closestBone.rotate(new Vec3(this.closestBone.ogEndpoint2.subtract(this.closestBone.ogPosition2).xyz), -GUI.rollSpeed));
  }
  else {
      this.camera.roll(GUI.rollSpeed, false);
  }
  break;
      }
      case "ArrowRight": {
		//TODO: Handle bone rolls when a bone is selected
    if (this.boneSelected) {
      //this.closestBone.boneRotation(this.closestBone.rotate(new Vec3(this.closestBone.ogEndpoint.xyz).normalize(), GUI.rollSpeed));
      this.closestBone.boneRotation(this.closestBone.rotate(new Vec3(this.closestBone.ogEndpoint2.subtract(this.closestBone.ogPosition2).xyz), GUI.rollSpeed));
    }
    else {
		this.camera.roll(GUI.rollSpeed, true);
    }
        break;
      }
      case "ArrowUp": {
        this.camera.offset(this.camera.up(), GUI.zoomSpeed, true);
        break;
      }
      case "ArrowDown": {
        this.camera.offset(this.camera.up().negate(), GUI.zoomSpeed, true);
        break;
      }
      case "KeyK": {
        if (this.mode === Mode.edit) {
		//TODO: Add keyframes if required by project spec
        }
        break;
      }      
      case "KeyP": {
        if (this.mode === Mode.edit && this.getNumKeyFrames() > 1)
        {
          this.mode = Mode.playback;
          this.time = 0;
        } else if (this.mode === Mode.playback) {
          this.mode = Mode.edit;
        }
        break;
      }
      case "KeyF": {
        if (this.boneSelected) {
          if(this.closestBone.parentIndex ==  -1){
            this.closestBone.boneTranslation(this.camera.right().negate().scale(1/5));
          }
        }
        
        break;

      }
      case "KeyG": {
        if (this.boneSelected) {
          if(this.closestBone.parentIndex ==  -1){
            this.closestBone.boneTranslation(this.camera.forward().scale(1/5));
          }
        }
        break;

      }
      case "KeyT": {
        if (this.boneSelected) {
          if(this.closestBone.parentIndex ==  -1){
            this.closestBone.boneTranslation(this.camera.forward().negate().scale(1/5));
          }
        }
        break;

      }
      case "KeyH": {
        if (this.boneSelected) {
          if(this.closestBone.parentIndex ==  -1){
            this.closestBone.boneTranslation(this.camera.right().scale(1/5));
          }
        }
        break;

      }
      
      case "KeyO": {
        if (this.boneSelected) {
          if(this.closestBone.parentIndex ==  -1){
            this.closestBone.boneTranslation(this.camera.up().scale(1/5));
          }
        }
        break;

      }
      
      case "KeyL": {
        if (this.boneSelected) {
          if(this.closestBone.parentIndex ==  -1){
            this.closestBone.boneTranslation(this.camera.up().negate().scale(1/5));
          }
        }
        break;

      }
      default: {
        console.log("Key : '", key.code, "' was pressed.");
        break;
      }
    }
  }

  /**
   * Registers all event listeners for the GUI
   * @param canvas The canvas being used
   */
  private registerEventListeners(canvas: HTMLCanvasElement): void {
    /* Event listener for key controls */
    window.addEventListener("keydown", (key: KeyboardEvent) =>
      this.onKeydown(key)
    );

    /* Event listener for mouse controls */
    canvas.addEventListener("mousedown", (mouse: MouseEvent) =>
      this.dragStart(mouse)
    );

    canvas.addEventListener("mousemove", (mouse: MouseEvent) =>
      this.drag(mouse)
    );

    canvas.addEventListener("mouseup", (mouse: MouseEvent) =>
      this.dragEnd(mouse)
    );

    /* Event listener to stop the right click menu */
    canvas.addEventListener("contextmenu", (event: any) =>
      event.preventDefault()
    );
  }
}
