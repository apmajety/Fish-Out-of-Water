# VirtualMannequin
Group members:
Aparna Majety (apm3222)
Sumedha Gonur (sg55696)

Contribution report: We pair programmed the entire project. 50-50.

Design decisions: 
Milestone 2: We decided to skip the 15 points for keyframe preview and keyframe management. Instead, we implemented extra extra credit (see below).
Milestone 1: For our bone picking, we decided to do the highlighting by changing the bone color instead of putting a visible cylinder. 


Extra Credit:

1. Copying animations to a string (5 points)
To invoke this feature, set up the keyframes as normal with the K key. Then, click C to automatically copy a string to clipboard. Either keep this string copied on the clipboard or save it for later. Then, reload the page or close the browser such that there is no keyframe animation on the rig. Then click V where you will paste the string from earlier into the input box. Now, the keyframes should be loaded, and the P should do playback as normal. 

Edge cases:
- You will be allowed to paste the string into any rig as long as the number of bones is the same, however, the animation will not work as intended since the positions of the bones in different rigs is different.

2. Custom Rig (10 Points)
Pressing the button 8 will give you an ant rig. Below I have attached some pictures of the ant in different poses.

![Standing Ant](src/skinning/static/static/assets/images/standing_ant.png)
![Jumping Ant](src/skinning/static/static/assets/images/jumping_ant.png)

Source: https://www.turbosquid.com/3d-models/rigged-stylized-green-cartoon-ant-character-1923792

3. Creative Scene
https://youtu.be/lcU0hgkE78c
We made a video with cool effects of our ant dancing to remixed music from the movie "A Bug's Life". 

4. Allowing user to specify arbitrary times between keyframes. Pressing T will add 1/4 second between each keyframe. Pressing G will subtract 1/4 second between each keyframe. This resets to default of 1 on key R and when rigs change.

5.Dual Quaternion Skinning
Implemented skinning based on this research paper: https://users.cs.utah.edu/~ladislav/kavan07skinning/kavan07skinning.pdf
This solves the candy wrapper rotations in linear blend skinnning, but dual quaternion has it's own quirk of when rotations happen in extreme angles. Linear blend skinning has been replaced with dual quaternion in milestone 2.
![Rotations with Dual Quat](src/skinning/static/static/assets/images/dog_arm.png)
![Rotations with Dual Quat](src/skinning/static/static/assets/images/dog_neck.png)
![Rotations with Dual Quat](src/skinning/static/static/assets/images/dog_side.png)
![Rotations with Dual Quat](src/skinning/static/static/assets/images/robot.png)

The dual quaternion solving the candy wrapper is noticable in the robot's spine rotation and in the dog's arm twisiting. 